package com.leb.player

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator

/** Intro animada de naturaleza (amanecer en el bosque) que termina con el logo L.E.B-M. */
class NatureIntro(ctx: Context, private val logo: Bitmap) : View(ctx) {
    private var p = 0f
    private var anim: ValueAnimator? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = java.util.Random(11)
    private val stars = Array(90) { floatArrayOf(rnd.nextFloat(), rnd.nextFloat() * 0.55f, 0.6f + rnd.nextFloat() * 1.6f) }
    private val trees = Array(26) { floatArrayOf(rnd.nextFloat(), 0.7f + rnd.nextFloat() * 0.9f, rnd.nextFloat() * 6.28f) }
    private val flies = Array(28) { floatArrayOf(rnd.nextFloat(), 0.55f + rnd.nextFloat() * 0.4f, rnd.nextFloat() * 6.28f) }

    /** Reproduce la animación desde [from] (0 = completa, 0.8 = solo el final con el logo). */
    fun play(from: Float, then: () -> Unit) {
        anim?.cancel()
        p = from
        var cancelled = false
        val a = ValueAnimator.ofFloat(from, 1f)
        a.duration = ((1f - from) * 7500).toLong().coerceAtLeast(600L)
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { p = it.animatedValue as Float; invalidate() }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationCancel(an: Animator) { cancelled = true }
            override fun onAnimationEnd(an: Animator) { if (!cancelled) postDelayed({ then() }, 700) }
        })
        anim = a
        post { a.start() }
    }

    override fun onDetachedFromWindow() { anim?.cancel(); super.onDetachedFromWindow() }

    private fun lerp(a: Int, b: Int, t: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt())

    private fun ridge(c: Canvas, w: Float, h: Float, base: Float, amp: Float, freq: Float, color: Int, ph: Float) {
        val path = Path(); path.moveTo(0f, h)
        var x = 0f
        while (x <= w + 8f) {
            val y = h * (base - amp * (0.5f * Math.sin((x / w * freq * 3.14 + ph).toDouble()).toFloat() + 0.5f * Math.sin((x / w * freq * 7.3 + ph * 2).toDouble()).toFloat()))
            path.lineTo(x, y); x += 8f
        }
        path.lineTo(w, h); path.close()
        paint.color = color; paint.alpha = 255; c.drawPath(path, paint)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w == 0f || h == 0f) return
        val t = minOf(1f, p / 0.62f)
        val tm = System.currentTimeMillis() % 100000L / 1000f
        // cielo: de la noche al amanecer
        paint.shader = LinearGradient(0f, 0f, 0f, h * 0.75f,
            intArrayOf(lerp(Color.parseColor("#070B26"), Color.parseColor("#3B7BD4"), t), lerp(Color.parseColor("#1B2A5E"), Color.parseColor("#FFB27A"), t), lerp(Color.parseColor("#3A2A6E"), Color.parseColor("#FFE2A8"), t)),
            floatArrayOf(0f, 0.7f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, paint); paint.shader = null
        // estrellas
        paint.color = Color.WHITE
        for (s in stars) { paint.alpha = ((1f - t) * 220).toInt().coerceIn(0, 255); c.drawCircle(s[0] * w, s[1] * h, s[2], paint) }
        // sol
        val sx = w * 0.7f; val sy = h * (0.80f - 0.30f * t)
        paint.shader = RadialGradient(sx, sy, w * 0.5f, intArrayOf(Color.argb((200 * t).toInt(), 255, 214, 140), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        c.drawCircle(sx, sy, w * 0.5f, paint); paint.shader = null
        paint.color = Color.rgb(255, 236, 190); paint.alpha = 255
        c.drawCircle(sx, sy, w * 0.075f, paint)
        // nubes
        paint.color = Color.WHITE
        for (i in 0 until 5) {
            val cx = ((i * 0.27f + p * 0.35f) % 1.3f - 0.15f) * w; val cy = h * (0.12f + 0.07f * i)
            paint.alpha = (90 + 60 * t).toInt()
            c.drawOval(RectF(cx - w * 0.16f, cy - h * 0.018f, cx + w * 0.16f, cy + h * 0.018f), paint)
            c.drawOval(RectF(cx - w * 0.09f, cy - h * 0.03f, cx + w * 0.07f, cy + h * 0.005f), paint)
        }
        // montañas
        ridge(c, w, h, 0.62f, 0.10f, 3f, lerp(Color.parseColor("#141A3D"), Color.parseColor("#6E7FB8"), t), 1.3f)
        ridge(c, w, h, 0.70f, 0.08f, 5f, lerp(Color.parseColor("#0F1530"), Color.parseColor("#3F5A8C"), t), 2.1f)
        ridge(c, w, h, 0.80f, 0.05f, 7f, lerp(Color.parseColor("#0A0F24"), Color.parseColor("#1F3A52"), t), 0.4f)
        // pinos
        paint.color = lerp(Color.parseColor("#050814"), Color.parseColor("#0F2A1E"), t); paint.alpha = 255
        for (tr in trees) {
            val x = tr[0] * w; val base = h * 0.9f; val sc = tr[1] * h * 0.11f
            val sway = Math.sin((tm * 1.2f + tr[2]).toDouble()).toFloat() * sc * 0.04f
            for (k in 0 until 3) {
                val yy = base - sc * (0.55f * k); val ww = sc * (0.55f - 0.13f * k)
                val path = Path(); path.moveTo(x + sway * (k + 1), yy - sc * 0.9f); path.lineTo(x - ww, yy); path.lineTo(x + ww, yy); path.close()
                c.drawPath(path, paint)
            }
        }
        c.drawRect(0f, h * 0.9f, w, h, paint)
        // luciérnagas
        paint.color = Color.rgb(255, 245, 160)
        for (f in flies) {
            val a = (Math.sin((tm * 2f + f[2]).toDouble()).toFloat() * 0.5f + 0.5f) * (1f - t * 0.6f)
            paint.alpha = (a * 230).toInt().coerceIn(0, 255)
            c.drawCircle((f[0] + Math.sin((tm * 0.5f + f[2]).toDouble()).toFloat() * 0.03f) * w, f[1] * h, 3.2f, paint)
        }
        // pájaros
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f; paint.color = Color.argb(200, 20, 20, 30)
        if (p > 0.25f) for (i in 0 until 5) {
            val bx = ((p - 0.25f) * 1.1f + i * 0.07f) * w; val by = h * (0.2f + 0.04f * i) - p * 20f
            val flap = Math.sin((tm * 8f + i).toDouble()).toFloat() * 8f
            val pa = Path(); pa.moveTo(bx - 14f, by + flap); pa.quadTo(bx - 6f, by - 6f, bx, by); pa.quadTo(bx + 6f, by - 6f, bx + 14f, by + flap)
            c.drawPath(pa, paint)
        }
        paint.style = Paint.Style.FILL
        // logo final L.E.B-M
        val q = ((p - 0.78f) / 0.22f).coerceIn(0f, 1f)
        if (q > 0f) {
            paint.color = Color.BLACK; paint.alpha = (q * 170).toInt(); c.drawRect(0f, 0f, w, h, paint)
            val size = w * 0.5f * (0.75f + 0.25f * q); val cx = w / 2; val cy = h * 0.42f
            paint.color = Color.WHITE; paint.alpha = (q * 255).toInt()
            c.drawBitmap(logo, null, RectF(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2), paint)
            paint.textAlign = Paint.Align.CENTER; paint.textSize = w * 0.042f
            c.drawText("Creado por Lautaro y Claude", cx, cy + size / 2 + w * 0.1f, paint)
            paint.textAlign = Paint.Align.LEFT
        }
    }
}
